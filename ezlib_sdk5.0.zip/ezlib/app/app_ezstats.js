/*****************************************************************************************/
/*                 CODE BELOW IS EZSTATS SYSTEM CODE - DO NOT MODIFY!                    */
/*                 Modifying may break the functionaltity                                */
/*                --> ONLY DO THIS IF YOU KNOW WHAT YOU ARE DOING <--                    */
/*****************************************************************************************/
                        /*Required Permissons*/
//• Internet
/*****************************************************************************************/
/*If any errors appear check if you impoted these files correctly or contact suppprt@ezstats.app*/
/*****************************************************************************************/
                              /*Guides*/
//• https://dev.fitbit.com/build/guides/file-system/
//• https://dev.fitbit.com/build/guides/communications/messaging/
//• https://dev.fitbit.com/build/reference/device-api/device/
//•                               
/*****************************************************************************************/


/*App imports*/
import document from "document";
import * as messaging from "messaging";
import { me as device } from "device";
import * as fs from "fs";
import { locale } from "user-settings";
import { me as appbit } from "appbit";

//Define variables
const log = console.log;
//Sign up for a API key at https://ezstats.app/
//Replace your API key here at https://ezstats.app/
var apikey = '087a4e22-d24e-42bb-a07d-6da6baaa38fb';
//Set to false when you publish your app!
var TEST_MODE = false;

//Export all of ezstats code to your main file
//THIS FUNCTION IS IMPORTANT DO NOT MODIFY
export function initialize() {
   
  if (!appbit.permissions.granted("access_internet")) {
    console.warn("We need the \'access_internet\' permisson to run! See #Required Permisson to see what permisson you need");
  }

// COnvert date to string
function toISOLocal(d) {  
    var z  = n =>  ('0' + n).slice(-2);
    var zz = n => ('00' + n).slice(-3);
    var off = d.getTimezoneOffset();
    var sign = off < 0? '+' : '-';
    off = Math.abs(off);
  
    var ISOLOCAL = d.getFullYear() + '-'
           + z(d.getMonth()+1) + '-' +
           z(d.getDate()) + 'T' +
           z(d.getHours()) + ':'  + 
           z(d.getMinutes()) + ':' +
           z(d.getSeconds()) + '.' +
           zz(d.getMilliseconds()) +
           sign + z(off/60|0) + ':' + z(off%60);     
    return ISOLOCAL;
}

function SENDEZSTATS() {
   var EZDATE = new Date();
   var STRINGDATE = "2000-01-01T00:00:00Z";
   var CURRDATE = new Date();
   //var CURRDATE = new Date('2021-02-18T00:00:00Z');
  
  // Check if file exists
  if (fs.existsSync("/private/data/EZDATE.cbor")) {
    // Read value in the file
    STRINGDATE = fs.readFileSync("EZDATE.cbor", "cbor");
    console.log("Object EZDATE: " + EZDATE.toDateString());
  } else {
    //If value does not exist set the dummy value into cbor
    fs.writeFileSync("EZDATE.cbor", STRINGDATE, "cbor");
    return true; // Send message because file doesn't exist    
  }
  EZDATE = new Date(STRINGDATE);

  log(`EZDATE: ${EZDATE} | CURRDATE: ${CURRDATE}`);

  if (EZDATE.getDate() !== CURRDATE.getDate()) {
    // Writing current date into file
    fs.writeFileSync("EZDATE.cbor", toISOLocal(CURRDATE), "cbor");    
    // Send message because date is different    
    return true;
  } else {
    return false;
  }

}



var EZUUID = createUUID();

function createUUID() {
  //check for UUID in cbor
  //if UUID exists then load UUID from cbor into var UUID
  var intuid;
  if (fs.existsSync("/private/data/EZUUID.cbor")) {
    intuid = fs.readFileSync("EZUUID.cbor", "cbor");
    console.log("Object UUID: " + intuid);
  } 
  if (!intuid) {
    //if UUID does not exist create new UUID  
    intuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);   
    });
    fs.writeFileSync("EZUUID.cbor", intuid, "cbor");    
  }
  return intuid;
}

//If connection state is open send the message
messaging.peerSocket.addEventListener("open", (evt) => {
  console.log("Ready to send or receive messages");
  sendMessage();
});

//Some error occured, send this error code and message to suppprt@ezstats.app
messaging.peerSocket.addEventListener("error", (err) => {
  console.error(`Connection error: ${err.code} - ${err.message}`);
});

function sendMessage() {
  if (SENDEZSTATS()) {
    log('Sending EZSTATS');
    let userdate;
    userdate = new Date().toString();
    // Set the user data into the API
    const ezdata = {
      title: 'User Data',
      isEzMsg: true,
      isSucess: true,
      records: ['apikey=' + apikey + '&testmode=' + TEST_MODE + '&Number_of_times=' + n + '&UUID=' + EZUUID + '&DEVICE_NAME=' + device.modelName + '&LOCALE=' + locale.language + '&userdate=' + userdate]
    }
    if (messaging.peerSocket.readyState === messaging.peerSocket.OPEN) {
      // Send the data to peer as a message      
      messaging.peerSocket.send(ezdata);           
    }

  } else {
    //Currently, we ONLY support one call per day
    console.log('Skipping EZSTATS, data already sent for today');    
  }

}

//app counter code IMPORTANT CODE DO NOT MODIFY
var n = "";
try 
{
    n = parseInt(fs.readFileSync("ezcounter.cbor", "cbor"));
} 
catch (ex) 
{
    n = 0;
}

//Increase the amount
n++;

//Write the counter value into cbor
fs.writeFileSync("ezcounter.cbor", n.toString(), "cbor");
   
/*****************************************************************************************/
/*If you want to clear the counter uncomment this code below. WHEN YOU PUBLISH YOUR APP RECOMMENT THE CODE OR ELSE THE COUNTER WILL ALWAYS RETURN 0 or 1!*/

/*
fs.unlinkSync("ezcounter.cbor");
*/

/*****************************************************************************************/
/*If you want to delete your EZUUID uncomment this code below. WHEN YOU PUBLISH YOUR APP RECOMMENT THE CODE OR ELSE THE EZUUID WILL ALWAYS RETURN null*/

/*
fs.unlinkSync("EZUUID.cbor");
*/

/*****************************************************************************************/

 }