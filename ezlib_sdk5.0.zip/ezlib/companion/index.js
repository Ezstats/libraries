/*
 * Entry point for the companion app
 */
import * as messaging from "messaging";
import * as ezstats from "./companion_ezstats.js";
import { localStorage } from "local-storage";

console.log("Companion code started");

ezstats.initialize();