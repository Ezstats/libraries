/*
 * Entry point for EZSTATS_COMPANION
 */
//Compainon import
import document from "document";
import * as messaging from "messaging";

//Export all of ezstats code to your comapnion file
//THIS FUNCTION IS IMPORTANT DO NOT MODIFY
export function initialize() {
  
  //A message was recived from EZSTATS
  messaging.peerSocket.addEventListener("message", (evt) => {
  console.log("Recd. Msg");
  if (evt.data.title && evt.data.title === "User Data") {
    if (evt.data.isEzMsg) {
    sendezstats(JSON.stringify(evt.data));
    }
  } else {
    console.log('Skipping non EZstats messages Content in logs Below.');
    console.log(evt.data);
  }
});

//Send the user data to the server
//THIS FUNCTION IS IMPORTANT DO NOT MODIFY
function sendezstats(sinput){  
  console.log("Sending "+sinput);
  fetch('https://api.ezstats.app/json', {
      method: 'post',
      headers: {
        'Content-Type': 'application/json'        
      },
      body: sinput
    }).then(function(response) {
      console.log("Recd. "+response.json().toString());
    }).then(function(data) {
      console.log("Recd. Data");
    }); 
  
}

  
}